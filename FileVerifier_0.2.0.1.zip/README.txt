////////////////////////////////////////////////////
//                                                //
// FileVerifier - Compare File Collections        //
//                                                //
// Authors:                                       //
//  Peter Buttgereit (Version 0.1)                //
//  https://github.com/pbuttgereit/FileVerifier   //
//                                                //
//  Bjoern Martensen (Version 0.2)                //
//  https://github.com/bmartensen/FileVerifier    //
//                                                //
// License: GNU LGPL Version 3 (see LICENSE.txt)  //
// Application icon: https://icons8.de/license    //
//                                                //
////////////////////////////////////////////////////
